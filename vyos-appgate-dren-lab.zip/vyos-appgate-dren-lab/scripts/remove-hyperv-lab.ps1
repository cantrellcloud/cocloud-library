[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$RepoRoot,
    [string[]]$VmNames = @(
        'AZ-PROTON-EXT','AZ-PROTON-OUT','AZ-PROTON-GREY','AZ-PROTON-INSIDE','AZ-PROTON-DEV','AZ-PROTON-SANDBOX',
        'ONP-OUT','ONP-GREY','ONP-INSIDE','ONP-DEV','ONP-SANDBOX'
    ),
    [string[]]$SwitchNames = @(
        'AZ-DREN','AZ-SDPC','AZ-SDPG','AZ-SDPT','AZ-AVD','AZ-DOMAIN','AZ-DOMSVC','AZ-DEV','AZ-DEVSVC','AZ-SEG','AZ-WAN',
        'ONP-DREN','ONP-SDPC','ONP-SDPG','ONP-SDPT','ONP-AVD','ONP-DOMAIN','ONP-DOMSVC','ONP-DEV','ONP-DEVSVC','ONP-SEG','ONP-HWIL','ONP-UNDERLAY'
    ),
    [switch]$RemoveVhds,
    [switch]$RemoveSwitches = $true
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = Split-Path -Parent $PSScriptRoot
}

foreach ($vmName in $VmNames) {
    $vm = Get-VM -Name $vmName -ErrorAction SilentlyContinue
    if ($null -eq $vm) {
        Write-Host "[SKIP] VM not found: $vmName"
        continue
    }

    if ($PSCmdlet.ShouldProcess($vmName, 'Remove VM')) {
        if ($vm.State -ne 'Off') {
            Stop-VM -Name $vmName -TurnOff -Force | Out-Null
        }

        $vhdPaths = @()
        if ($RemoveVhds) {
            $vhdPaths = Get-VMHardDiskDrive -VMName $vmName | Select-Object -ExpandProperty Path
        }

        Remove-VM -Name $vmName -Force | Out-Null
        Write-Host "[OK] VM removed: $vmName"

        foreach ($path in $vhdPaths) {
            if (Test-Path $path) {
                Remove-Item -Path $path -Force
                Write-Host "[OK] VHD removed: $path"
            }
        }
    }
}

if ($RemoveSwitches) {
    foreach ($switchName in $SwitchNames) {
        $switch = Get-VMSwitch -Name $switchName -ErrorAction SilentlyContinue
        if ($null -eq $switch) {
            Write-Host "[SKIP] Switch not found: $switchName"
            continue
        }

        if ($PSCmdlet.ShouldProcess($switchName, 'Remove VMSwitch')) {
            Remove-VMSwitch -Name $switchName -Force
            Write-Host "[OK] Switch removed: $switchName"
        }
    }
}

Write-Host 'Done.'
